#!/usr/bin/env python3
"""Compile a display-only MH370 viewer from nine frozen, published safe exports.

No imports from campaign code, no propagation, no raw record access, no network.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import math
import re
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SRC = HERE / 'safe_exports'
OUT = ROOT / 'dist' / 'assets' / 'data.js'
CATALOGUE = 'de50a5206e940fcb34acf587f98e849f9f4e98b5'
EPOCH = '2014-03-08T00:19:37Z'
TREATMENTS = [
    'envelope_frozen_equations__no_warmup_feasible',
    'envelope_frozen_equations__warmup_feasible',
    'envelope_historical_offset__no_warmup_feasible',
    'envelope_historical_offset__warmup_feasible',
]


def num(value):
    if value is None or value == '' or value == 'None':
        return None
    v = float(value)
    return v if math.isfinite(v) else None


def integer(value):
    v = num(value)
    return int(v) if v is not None else 0


def boolean(value):
    if value in (None, ''):
        return None
    if str(value).lower() in ('true', '1'):
        return True
    if str(value).lower() in ('false', '0'):
        return False
    raise ValueError(f'Unrecognised boolean {value!r}')


def rows(name):
    return list(csv.DictReader((SRC / name).open(newline='')))


def csv_section(text, heading):
    block = text.split(heading + '\n', 1)[1].split('\n\n', 1)[0]
    return list(csv.DictReader(io.StringIO(block)))


def is_protected_field(name):
    return bool(re.search(r'2241|22[:_]41', name, re.I))


def main():
    manifest = json.loads((HERE / 'source_manifest.json').read_text())
    for source in manifest['sources']:
        data = (SRC / source['name']).read_bytes()
        assert hashlib.sha256(data).hexdigest() == source['sha256'], source['name']
        assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == source['gitBlob']
        if source['name'].endswith('.csv'):
            header = data.split(b'\n', 1)[0].decode('utf-8')
            assert not any(is_protected_field(x) for x in next(csv.reader([header]))), source['name']

    configs_raw = rows('GLOBAL_CONFIGURATIONS.csv')
    grid_raw = [r for r in configs_raw if r['catalogue'] == 'FPC']
    evidence_codes = {
        'computed in this experiment': 'computed',
        'not computed in this campaign; an exact earlier result exists (separate experiment)': 'historicalExact',
        'not computed; only a near match exists (kept separate, different climb start)': 'historicalNear',
        'no flight evidence of any kind': 'none',
    }
    dimension_columns = {
        'search': 'dim_search', 'nativeSupport': 'dim_native_support',
        'policy': 'dim_policy', 'fuel': 'dim_fuel_class',
        'terminal': 'dim_terminal', 'measurement': 'dim_measurement', 'numerical': 'dim_numerical',
    }
    dimension_sets = []
    dimension_lookup = {}
    grid = []
    arrivals = {}
    for r in grid_raw:
        dimensions = {k: r[v] for k, v in dimension_columns.items()}
        dim_key = json.dumps(dimensions, sort_keys=True)
        if dim_key not in dimension_lookup:
            dimension_lookup[dim_key] = len(dimension_sets)
            dimension_sets.append(dimensions)
        is_policy = r['dim_policy'] == 'SUPPLEMENTAL_POLICY_STOP'
        early = r['dim_fuel_class'] == 'FUEL_BEFORE_REQUIRED_POWERED_EPOCH'
        if r['dim_search'] == 'UNCOMPUTED':
            status = 'uncomputed'
        elif r['dim_measurement'] == 'COMPUTED_COMPATIBLE_RESPONSE':
            status = 'compatible'
        elif is_policy and early:
            status = 'policyAndEarlyFuel'
        elif is_policy:
            status = 'policyStop'
        elif early:
            status = 'earlyFuel'
        elif r['dim_fuel_class'] == 'FUEL_AFTER_FINAL_TRANSMISSIONS_OUTSIDE_RESPONSE_FAMILY':
            status = 'stillPowered'
        elif r['dim_measurement'] == 'FIRST_TURN_TIMING_OUTSIDE_ACCEPTANCE':
            status = 'timingMiss'
        elif r['dim_terminal'] == 'TERMINAL_MAP_INCOMPLETE':
            status = 'terminalIncomplete'
        else:
            status = 'other'
        a = int(r['arrival_index'])
        climb = num(r['climb_start_s'])
        grid.append({
            'id': r['config_uid'], 'cellId': r['cell_id'], 'arrival': a,
            'mach': num(r['commanded_Mach_after_2041']), 'climbSeconds': climb,
            'noClimb': r['climb_role'] == 'NO_CLIMB', 'climbRole': r['climb_role'],
            'evidence': evidence_codes[r['evidence_state']], 'status': status,
            'compatibleCount': integer(r['responses_compatible_any_treatment']),
            'returnedCount': integer(r['returned_flights']),
            'responseCount': integer(r['responses_computed']),
            'dimensionSet': dimension_lookup[dim_key],
            'reason': r['recorded_reason'] or None,
            'historicalMatch': r['earlier_work_match'] or None,
            'historicalLinkedIds': r['earlier_configurations_linked'] or None,
        })
        if a not in arrivals:
            arrivals[a] = {
                'index': a, 'id': r['arrival_id'], 'firstLeg': r['first_leg'],
                'heightM': num(r['arrival_height_m']), 'fuelKg': num(r['arrival_fuel_kg']),
                'massKg': num(r['arrival_total_mass_kg']),
                'massOrigin': 'ALGEBRAIC_DERIVATION: fixed non-fuel mass plus recorded fuel',
            }

    grid_by_id = {r['id']: r for r in grid}
    flights = []
    for r in rows('GLOBAL_FLIGHTS.csv'):
        flights.append({
            'id': r['flight_uid'], 'configId': r['config_uid'],
            'arrival': int(r['arrival_index']), 'mach': num(r['commanded_Mach_after_2041']),
            'climbSeconds': num(r['climb_start_s']), 'fuelMultiplier': num(r['fuel_multiplier']),
            'representative': boolean(r['is_fuel_event_representative']),
            'witnessType': r['witness_type'],
            'turns': {'firstOffsetDeg': num(r['first_turn_offset_deg']),
                      'secondStartSeconds': num(r['second_turn_start_s']),
                      'secondOffsetDeg': num(r['second_turn_offset_deg'])},
            'fittedBtoResidualUs': {epoch: num(r[f'bto_residual_{key}_us_FITTED']) for epoch, key in [('20:41:05','2041'),('21:41:27','2141'),('00:11:00','0011')]},
            'diagnosticBfoCentredResidualHz': {epoch: num(r[f'bfo_centred_residual_{key}_hz_DIAGNOSTIC']) for epoch, key in [('20:41:05','2041'),('21:41:27','2141'),('00:11:00','0011')]},
            'fuelAt1941Kg': num(r['fuel_1941_kg']), 'fuelAt0011Kg': num(r['fuel_0011_kg']),
            'heightAt2141M': num(r['height_2141_m']), 'heightAt0011M': num(r['height_0011_m']),
            'latAt0011': num(r['latitude_0011_deg']), 'lonAt0011': num(r['longitude_0011_deg']),
            'averageBurn2141To0011KgH': num(r['average_burn_2141_to_0011_kg_h_DERIVED']),
            'fuelEventMinusLogonSeconds': num(r['fuel_exhaustion_minus_0019_29_s']),
            'fuelClass': r['fuel_class'], 'machAtFuelEvent': num(r['realised_Mach_at_fuel_exhaustion']),
            'responseCount': integer(r['terminal_responses']),
            'compatibleCount': integer(r['compatible_responses_any_treatment']),
            'poweredCheck': r['powered_flight_numerical_check'] or 'NO_NUMERICAL_CHECK_IMPORTED',
        })
    flight_by_id = {r['id']: r for r in flights}
    for flight in flights:
        # This summary export retains only one powered position per flight.
        # A height at another epoch is not enough to construct a waypoint.
        arrival = arrivals[flight['arrival']]
        non_fuel_mass = arrival['massKg'] - arrival['fuelKg']
        fuel = flight['fuelAt0011Kg']
        flight['states'] = [{
            'epoch':'2014-03-08T00:11:00Z','elapsedSeconds':16197,'phase':'powered',
            'lat':flight['latAt0011'],'lon':flight['lonAt0011'],'heightM':flight['heightAt0011M'],
            'fuelKg':fuel,'massKg':non_fuel_mass + fuel if fuel is not None else None,
            'massOrigin':'ALGEBRAIC_DERIVATION: arrival non-fuel mass plus recorded fuel',
            'groundSpeedMps':None,'trackDeg':None,'verticalSpeedMps':None,'mach':None,
            'commandedMach':flight['mach'],'bankDeg':None,'liftN':None,'dragN':None,
            'pressurePa':None,'tempK':None,'trueAirspeedMps':None,
            'origin':'Saved 00:11 state in GLOBAL_FLIGHTS.csv; other coordinates absent from this export',
        }] if flight['latAt0011'] is not None else []
    geo = rows('GLOBAL_COMPATIBLE_GEOGRAPHY_BY_TREATMENT.csv')
    reported_extreme_checks = {}
    for r in geo:
        if r['experiment'] == 'FPC':
            for d in ['northernmost','southernmost','easternmost','westernmost']:
                reported_extreme_checks['FPC|' + r[d + '_response']] = r[d + '_check_of_its_flight']

    points = []
    for r in rows('FPC_NEW_COMPATIBLE_POSITIONS.csv'):
        if r['epoch'] != '0019_37':
            continue
        uid = 'FPC|' + r['response']
        flight_id = uid.rsplit('|', 2)[0]
        g = grid_by_id['FPC|' + r['cell_id']]
        points.append({
            'id': uid, 'experiment': 'FPC', 'configId': 'FPC|' + r['cell_id'],
            'flightId': flight_id, 'arrival': g['arrival'], 'mach': num(r['target_Mach']),
            'climbSeconds': num(r['climb_start_s']), 'fuelMultiplier': 1.0,
            'lat': num(r['latitude']), 'lon': num(r['longitude']), 'heightM': num(r['height_m']),
            'compatible': True, 'treatments': json.loads(r['flags']),
            'bankDeg': num(r['bank_deg']), 'onsetSeconds': num(r['onset_offset_s']),
            'alongArcKm': num(r['along_arc_km']), 'arcOffsetKm': num(r['offset_from_arc_km']),
            'check': reported_extreme_checks.get(uid, 'NO_RESPONSE_CHECK_IMPORTED'),
            'checkSourceScope': 'Published extreme/witness check when imported; no blanket response verification',
            'poweredCheck': flight_by_id.get(flight_id, {}).get('poweredCheck', 'NO_NUMERICAL_CHECK_IMPORTED'),
            'source': 'FPC_NEW_COMPATIBLE_POSITIONS.csv',
        })
    for r in rows('SCE_ONSET_RESULTS.csv'):
        if not r['lat_0019_37'] or not r['lon_0019_37']:
            continue
        uid = f"SCE|{r['cell_id']}|{float(r['bank_deg']):+g}|O{float(r['onset_offset_s']):+g}"
        points.append({
            'id': uid, 'experiment': 'SCE', 'configId': 'SCE|' + r['cell_id'], 'flightId': 'SCE|' + r['cell_id'],
            'arrival': None, 'arrivalLabel': r['arrival'], 'mach': num(r['target_Mach']),
            'climbSeconds': num(r['climb_start_s']), 'fuelMultiplier': 1.0,
            'lat': num(r['lat_0019_37']), 'lon': num(r['lon_0019_37']), 'heightM': num(r['height_m_0019_37']),
            'compatible': boolean(r['compatible']), 'treatments': {k: boolean(r[k]) for k in TREATMENTS},
            'bankDeg': num(r['bank_deg']), 'onsetSeconds': num(r['onset_offset_s']),
            'verticalSpeedMps': num(r['vertical_speed_mps_0019_37']),
            'check': 'NO_NUMERICAL_CHECK_IMPORTED', 'source': 'SCE_ONSET_RESULTS.csv',
        })
    for r in rows('NBT_ONSET_RESULTS.csv'):
        if not r['lat_0019_37'] or not r['lon_0019_37']:
            continue
        points.append({
            'id': 'NBT|' + r['key'], 'experiment': 'NBT', 'configId': 'NBT|' + r['case_id'],
            'flightId': 'NBT|' + r['case_id'], 'arrival': None, 'mach': None,
            'scheduleLabel': r['branch'], 'fuelMultiplier': 1.0,
            'lat': num(r['lat_0019_37']), 'lon': num(r['lon_0019_37']), 'heightM': num(r['height_0019_37_m']),
            'realisedTerminalMach': num(r['Mach_0019_37']),
            'compatible': boolean(r['compatible']), 'treatments': None,
            'bankDeg': num(r['bank_deg']), 'onsetSeconds': num(r['onset_offset_s']),
            'check': 'NO_NUMERICAL_CHECK_IMPORTED', 'source': 'NBT_ONSET_RESULTS.csv',
        })
    taco_flags = dict(zip(TREATMENTS, ['no_warmup','warmup','no_warmup_hist','warmup_hist']))
    for r in rows('TACO_GRID_RESULTS.csv'):
        if not r['lat_0019_37'] or not r['lon_0019_37']:
            continue
        multiplier = num(r['lambda_ff'])
        points.append({
            'id': 'TACO|' + r['key'], 'experiment': 'TACO',
            'configId': f"TACO|{r['case_id']}|L{multiplier:.3f}",
            'flightId': f"TACO|{r['case_id']}|L{multiplier:.3f}", 'arrival': None, 'mach': None,
            'scheduleLabel': r['family'], 'fuelMultiplier': multiplier,
            'lat': num(r['lat_0019_37']), 'lon': num(r['lon_0019_37']), 'heightM': num(r['height_0019_37_m']),
            'realisedTerminalMach': num(r['Mach_0019_37']),
            'verticalSpeedMps': num(r['vertical_speed_0019_37_mps']),
            'compatible': boolean(r['compatible']), 'treatments': {k: boolean(r[v]) for k,v in taco_flags.items()},
            'bankDeg': num(r['bank_deg']), 'onsetSeconds': num(r['onset_offset_s']),
            'check': 'NO_NUMERICAL_CHECK_IMPORTED', 'source': 'TACO_GRID_RESULTS.csv',
        })

    witness_text = (SRC / 'EXAMPLE_FLIGHT_A03_M0.6550_CS14397_R0.txt').read_text()
    assert not is_protected_field(witness_text), 'Worked example must contain no withheld epoch'
    flight_info = csv_section(witness_text, 'FLIGHT FPC|A03_M0.6550_CS14397.000#R0')[0]
    witness_states = []
    for r in csv_section(witness_text, 'States along the flight (handshake epochs and fuel exhaustion; nothing between them is stored):'):
        witness_states.append({
            'epoch': r['epoch_utc'], 'elapsedSeconds': num(r['elapsed_s']), 'kind': r['sample_kind'],
            'phase': 'fuelEvent' if r['sample_kind'] == 'fuel_exhaustion_event_state' else 'powered',
            'lat': num(r['latitude_deg']), 'lon': num(r['longitude_deg']), 'heightM': num(r['height_m']),
            'groundSpeedMps': num(r['ground_speed_mps']), 'trackDeg': num(r['ground_track_deg']),
            'verticalSpeedMps': num(r['vertical_speed_mps']), 'realisedMach': num(r['realised_Mach']),
            'commandedMach': num(r['commanded_Mach']), 'fuelKg': num(r['remaining_fuel_kg']),
            'massKg': num(r['total_mass_kg']), 'massOrigin': r['total_mass_origin'],
            'liftN': None, 'dragN': None, 'thrustN': None, 'windENU': None,
            'origin': 'Published saved state; missing fields remain null',
        })
    terminal_columns = {
        'heightAboveSurfaceM':'height_above_surface_m', 'groundSpeedMps':'ground_speed_mps',
        'trackDeg':'ground_track_deg','verticalSpeedMps':'vertical_speed_mps',
        'tasMps':'true_airspeed_mps','casMps':'calibrated_airspeed_mps',
        'realisedMach':'realised_Mach_unpowered_descent','machMax':'mach_max',
        'bankDeg':'bank_deg','airPathAngleDeg':'air_path_angle_deg',
        'liftCoefficient':'lift_coefficient','clMax':'cl_max','buffetMargin':'buffet_margin',
        'liftN':'lift_N','dragN':'drag_N','dragCoefficient':'drag_coefficient','loadFactor':'load_factor',
        'massKg':'total_mass_kg','fuelKg':'APU_reserve_kg','pressurePa':'pressure_Pa',
        'temperatureK':'temperature_K','alongArcKm':'along_arc_km','arcOffsetKm':'offset_from_arc_km',
    }
    for index, r in enumerate(csv_section(witness_text, 'States at the two final transmissions (recorded):')):
        state = {
            'epoch': r['epoch_utc'], 'elapsedSeconds': 16706 + index*8, 'kind': 'terminal_response_state',
            'phase': 'unpoweredDescent', 'lat': num(r['latitude_deg']), 'lon': num(r['longitude_deg']),
            'heightM': num(r['height_m']), 'velocityENU': [num(r[k]) for k in ['v_east_mps','v_north_mps','v_up_mps']],
            'weatherCoverage': r['weather_coverage'], 'origin': 'RECORDED', 'massOrigin': 'RECORDED',
            'commandedMach': None, 'thrustN': None, 'windENU': None,
        }
        state.update({k:num(r[v]) for k,v in terminal_columns.items()})
        witness_states.append(state)
    intervals = [{
        'fromEpoch': r['from_epoch_utc'], 'toEpoch': r['to_epoch_utc'],
        'seconds': num(r['interval_s']), 'fuelUsedKg': num(r['fuel_used_kg']),
        'averageKgH': num(r['interval_average_fuel_burn_kg_h']), 'origin': 'ALGEBRAIC_DERIVATION',
    } for r in csv_section(witness_text, 'Interval-average fuel burn (fuel difference / elapsed time; not instantaneous):')]
    satellite = []
    for heading, phase in [('Satellite quantities at permitted epochs:', 'powered'), ('Satellite quantities of this response:', 'terminal')]:
        for r in csv_section(witness_text, heading):
            satellite.append({'epoch':r['epoch_utc'],'observable':r['observable'],'quantity':r['quantity'],
                              'value':num(r['value']),'unit':r['unit'],'role':r.get('role',r.get('convention')),'phase':phase})
    response_check = csv_section(witness_text, 'Numerical check of THIS response (terminal propagation repeated from the tighter fuel-exhaustion state):')[0]
    witness = {
        'flightId':'FPC|A03_M0.6550_CS14397.000#R0',
        'responseId':'FPC|A03_M0.6550_CS14397.000#R0|-60|O-9',
        'configId':flight_info['config_uid'],'arrivalId':flight_info['arrival_id'],
        'targetMach':num(flight_info['target_Mach']),'climbSeconds':num(flight_info['climb_start_text']),
        'turns':json.loads(flight_info['fitted_turn_parameters']), 'states':witness_states,
        'intervalBurns':intervals,'satellite':satellite,
        'treatments':{r['treatment']:boolean(r['feasible']) for r in csv_section(witness_text,'The four terminal treatments, separately:')},
        'check':{'status':'VERIFIED_AT_HALF_STEP','poweredStepSeconds':num(response_check['step_s']),
                 'terminalPositionDifferenceM':num(response_check['d_pos_m']),
                 'velocityDifferenceMps':num(response_check['d_vel_mps']),
                 'bfoDifferenceHz':num(response_check['d_bfo_hz']),
                 'btoDifferenceUs':num(response_check['d_bto_us']),
                 'compatibilityUnchanged':True,'statusUnchanged':True,'stopUnchanged':True},
        'trajectoryNote':'Seven recorded checkpoints only. Lines between checkpoints are visual guides, not a recovered continuous trajectory.',
        'forceNote':'Lift and drag are retained only at the two terminal checkpoints. Thrust, wind and powered forces are not inferred.',
    }
    for state in witness_states:
        state['mach'] = state.get('realisedMach')
        state['tempK'] = state.get('temperatureK')
        state['trueAirspeedMps'] = state.get('tasMps')
        for field in ['bankDeg','pressurePa','liftN','dragN']:
            state.setdefault(field, None)
    for point in points:
        point['epoch'] = EPOCH
        point['verification'] = point['check']
        point['origin'] = 'RECORDED_PUBLISHED_FINAL_STATE'
        if point['experiment'] == 'SCE':
            point['identityOrigin'] = 'COMPOSITE_KEY_FROM_SOURCE_CELL_BANK_ONSET'
    point_counts = dict(Counter(p['experiment'] for p in points))
    compatible_counts = dict(Counter(p['experiment'] for p in points if p['compatible']))
    evidence_counts = dict(Counter(g['evidence'] for g in grid))
    status_counts = dict(Counter(g['status'] for g in grid))
    assert len(grid) == 5750 and len(set(g['id'] for g in grid)) == 5750
    assert len(arrivals) == 22 and len(set(g['mach'] for g in grid)) == 23
    assert evidence_counts == {'computed':292,'none':5394,'historicalExact':60,'historicalNear':4}, evidence_counts
    assert len(flights) == 278 and len(set(f['id'] for f in flights)) == 278
    assert sum(g['compatibleCount'] for g in grid) == 376
    assert point_counts == {'FPC':376,'SCE':830,'NBT':597,'TACO':1368}, point_counts
    assert compatible_counts == {'FPC':376,'SCE':244,'NBT':185,'TACO':378}, compatible_counts
    assert len(set(p['id'] for p in points)) == len(points)
    assert len(witness_states) == 7 and len(intervals) == 4
    assert all(p['lat'] is not None and p['lon'] is not None and p['heightM'] is not None for p in points)
    assert all(-90 <= p['lat'] <= 90 and -180 <= p['lon'] <= 180 for p in points)
    for p in points:
        if p['treatments'] is not None:
            assert p['compatible'] == any(p['treatments'].values()), p['id']
    counts = {
        'gridConfigurations':len(grid),'arrivals':len(arrivals),'machLevels':23,
        'evidence':evidence_counts,'status':status_counts,'flightSummaries':len(flights),
        'finalPoints':len(points),'finalPointsByExperiment':point_counts,
        'compatibleFinalPoints':sum(compatible_counts.values()),'compatibleFinalPointsByExperiment':compatible_counts,
        'campaignAllTerminalResponses':3016,'campaignCompatibleResponses':376,
        'campaignFinalPointExportScope':'Only compatible FPC final states are supplied by NEW_COMPATIBLE_POSITIONS.csv. Historical final-state exports include compatible and incompatible states.',
        'witnessCheckpoints':7,'sourcesVerified':len(manifest['sources']),
    }
    data = {
        'meta':{
            'schemaVersion':'1.0','title':'MH370 Flight Dynamics Lab — saved-state evidence',
            'catalogueCommit':CATALOGUE,'scientificBaselineCommit':manifest['scientificBaselineCommit'],
            'finalEpoch':EPOCH,'timeOrigin':'2014-03-07T19:41:03Z','logonEpoch':'2014-03-08T00:19:29Z',
            'mode':'Display-only compilation; no new flight computation',
            'coordinateFrame':'Published geodetic latitude/longitude; height_m as model ellipsoid height. height_above_surface is separate where recorded.',
            'velocityFrame':'Local east, north, up (ENU), m/s',
            'sourceOrigin':'Frozen published safe summaries and exports; no raw record stores opened',
            'seal':'The withheld observation/predictions were not read. The lower-speed experiment is outside this snapshot.',
            'cautions':[
                'Final points are conditional airborne model states at the last transmission, not impact positions.',
                'Computed density is not probability; one flight may carry multiple terminal responses.',
                'Uncomputed configurations remain uncomputed. Historical exact matches are separate experiments.',
                'Policy stops, physical model-support stops, fuel-family exclusions and measurement failures are different outcomes.',
                'A bounded search failure does not prove impossibility across other turns, climbs or model assumptions.',
                'Treatment union does not establish compatibility under a single common terminal treatment.',
                'Only published witness checks are imported; compatibility is distinct from numerical verification.',
                'No drift, breakup or impact model is included.',
            ],
        },
        'units':{
            'lat':'degrees north (negative south)','lon':'degrees east',
            'heightM':'metres, model ellipsoid','heightAboveSurfaceM':'metres above model surface',
            'mach':'dimensionless, commanded powered schedule; separate from realised terminal Mach',
            'climbSeconds':'seconds after 19:41:03; null with noClimb=true means no climb',
            'onsetSeconds':'seconds relative to 00:19:29 log-on',
            'groundSpeedMps':'m/s','verticalSpeedMps':'m/s, up positive',
            'tasMps':'true airspeed, m/s','casMps':'calibrated airspeed, m/s',
            'trackDeg':'degrees clockwise from true north','bankDeg':'signed degrees as stored by model',
            'fuelKg':'kg','massKg':'kg','averageKgH':'kg/h, interval average, not instantaneous',
            'liftN':'newtons','dragN':'newtons','thrustN':'newtons; null where not retained',
            'temperatureK':'kelvin','pressurePa':'pascals','alongArcKm':'km, frozen arc convention',
            'fittedBtoResidualUs':'microseconds, fitted permitted epochs',
            'diagnosticBfoCentredResidualHz':'Hz; diagnostic, not part of timing fit',
            'terminalBfoResidual':'Raw recorded residual; not a residual corrected for treatment. Do not compare directly against a 7 Hz acceptance band.',
        },
        'sources':manifest['sources'],'counts':counts,
        'fieldOrigins':{
            'configurations':'GLOBAL_CONFIGURATIONS.csv at pinned catalogue commit; compact status derived from seven separately retained dimensions',
            'flights':'GLOBAL_FLIGHTS.csv; positions and scalar model states recorded; average fuel burn is an algebraic derivation',
            'points':'Named safe terminal-response export per row; source identity and treatment booleans retained; no inferred locations',
            'witness.states':'Seven recorded checkpoint rows from the published worked example; powered masses explicitly derived where labelled',
            'witness.intervalBurns':'Fuel difference divided by recorded elapsed time; not instantaneous fuel flow',
            'null':'Field not retained in the selected safe export; not zero, not a simulated estimate',
        },
        'treatmentKeys':TREATMENTS,
        'dimensionSets':dimension_sets,
        'dimensionLabels':dimension_columns,
        'evidenceLabels':{v:k for k,v in evidence_codes.items()},
        'statusLabels':{
            'uncomputed':'Not computed in campaign','compatible':'Compatible terminal response found',
            'policyStop':'Supplemental Mach policy stop','policyAndEarlyFuel':'Policy stop and early fuel in searched trials',
            'earlyFuel':'Fuel exhausted before required powered epoch in searched trials',
            'stillPowered':'Fuel event after final transmissions; outside studied response family',
            'timingMiss':'First-turn timing misses acceptance in searched trials',
            'terminalIncomplete':'Searched; terminal stage not complete',
        },
        'arrivals':[arrivals[k] for k in sorted(arrivals)],
        'configurations':grid,'flights':flights,'points':points,'witness':witness,
        'geographyByTreatment':geo,
        'coverage':rows('GLOBAL_COVERAGE_BY_ARRIVAL_AND_MACH.csv'),
        'validation':{'sourceHashes':'9 / 9 verified','checks':'Grid identities, evidence counts, 22 arrivals, 23 Mach levels, flight identities, response identity and treatment consistency, finite coordinates, witness coverage all passed.'},
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    encoded = json.dumps(data, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
    OUT.write_text('/* Generated by source/compile_data.py from pinned safe exports. */\nwindow.MH370_DATA=' + encoded + ';\n')
    print(json.dumps({'output':str(OUT),'bytes':OUT.stat().st_size,'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'counts':counts},indent=2))


if __name__ == '__main__':
    main()
