# MH370 Flight Dynamics Lab

A buildless, static research viewer for the recorded MH370 flight catalogue. The application links the declared parameter grid, saved geographic states and explanatory flight physics. **It is a user interface over published evidence, not a new numerical solver.**

## Run and rebuild

Serve `dist/` with any static web server. For local development, from this repository:

```sh
python3 -m http.server 8000 --directory dist
```

Open `http://localhost:8000`. There is no package installation or application build step. To regenerate the data asset from the checked-in safe exports:

```sh
python3 source/compile_data.py
```

The compiler uses the Python standard library, reads only the nine local files named in `source/source_manifest.json`, verifies their hashes and writes `dist/assets/data.js`. The script performs no network access, imports no campaign code and computes no new flight. `source/validation_report.json` records the validated snapshot.

## Data included

| Dataset | Actual scope |
| --- | --- |
| Configuration grid | 5,750 configurations, 22 arrivals, 23 Mach levels |
| Campaign flight summaries | 278 returned flights, each with one exported 00:11 powered position |
| Geographic scatter | 3,171 saved airborne states at 00:19:37, across four experiments |
| Worked witness | Seven saved checkpoints, four interval-average fuel burns and permitted satellite quantities |

The grid's evidence partition is 292 computed in this campaign, 60 uncomputed here with an exact historical result, four with only a near match and 5,394 with no flight evidence identified. Historical matches remain separate experiments. Their presence does not turn an uncomputed campaign cell into a computed one.

| Final-state source | Saved states | Compatible under at least one reported treatment |
| --- | ---: | ---: |
| FPC: full-population campaign / narrow finish | 376 | 376 |
| SCE: speed and climb envelope | 830 | 244 |
| NBT: climbed branches | 597 | 185 |
| TACO: earlier candidate response catalogue | 1,368 | 378 |
| **Total imported** | **3,171** | **1,183** |

The FPC position export supplies **compatible positions only**. The campaign has 3,016 terminal responses in its broader record; this scatter is not an inventory of all those positions. Historical final-state exports include compatible and incompatible responses. Multiple responses can belong to one powered flight, so counts and point density are not probabilities.

## Provenance and interpretation

Catalogue summaries are pinned to `de50a5206e940fcb34acf587f98e849f9f4e98b5` in `floydclaptonblues/MH370-Ocean-GLORYS-Data`. Historical and campaign terminal-position exports are pinned to scientific baseline `31b6b16ef4ddcc8cad153b56ae2e380f838046dd`. Every source's exact path, source URL, Git blob ID, byte length and SHA-256 appear in `source/source_manifest.json`. Nine byte streams matched their Git blobs; repeated builds produced identical data.

The compiler retains seven separate configuration dimensions: search, native support, supplemental policy, fuel event, terminal coverage, measurement compatibility and numerical check. Compact display statuses do not replace those dimensions. A policy stop is not an aircraft-performance limit; a fuel-family exclusion is not a satellite rejection; and an unsuccessful bounded search is not a mathematical proof of impossibility.

The four terminal treatments remain separate booleans. NBT has only union compatibility in its export, represented by `treatments: null`; it must not appear as passing a specific treatment. Five exact FPC extreme/witness responses carry an imported `VERIFIED_AT_HALF_STEP` label. Other responses say no check was imported. A powered-flight check is stored separately and does not certify every terminal response associated with that flight.

All plotted final points are conditional **airborne model states at the transmission epoch**, not impact positions or a ranked search area. The lower-speed experiment is outside this snapshot.

## Recorded and illustrative content

`window.MH370_DATA` exposes `configurations`, `dimensionSets`, `arrivals`, `flights`, `points`, `witness`, `counts`, `units`, `fieldOrigins` and `sources`.

- Coordinates, saved velocities, fuel, mass, retained forces and satellite quantities come from the named exports. Their units and origins travel with the data.
- The worked witness has five powered/event states and two terminal states. Lines joining those checkpoints are visual guides. They are not a recovered continuous trajectory, and intermediate positions or forces are not evidence.
- Each other returned-flight summary has one complete exported powered position at 00:11. A height recorded at another epoch is insufficient to construct another waypoint.
- Terminal lift, drag, bank, airspeed, pressure and temperature are recorded for the worked witness. Powered lift/drag, local wind and thrust are absent from these exports and remain `null`.
- The powered target Mach and realised Mach during the unpowered descent are different quantities. Fuel burn derived from two saved fuel values is an interval average, not instantaneous flow.
- Force diagrams and coupling explanations illustrate relationships. Camera projection, vertical exaggeration and display arrow scaling do not change the scientific values.

The withheld 22:41 observation, predictions and residuals were not accessed. Raw record stores, checkpoints and ledgers were not opened. Future importers must preserve the same protection and must not decode mixed protected records first and redact them afterward.

## Safe export contract for a future continuous state viewer

A complete time-resolved animation needs a purpose-built, allowlisted state export from the existing scientific workflow. Each retained sample should carry the following, with explicit units, coordinate conventions and missing-value status:

| Field group | Required content |
| --- | --- |
| Identity and provenance | Experiment, configuration, flight and response IDs; source commit; model/policy version; fuel-flow multiplier; sample origin; numerical-check scope |
| Time and position | UTC and elapsed seconds; latitude, longitude, ellipsoid height; surface-relative height separately if available |
| Motion and atmosphere | Ground velocity in east/north/up coordinates; wind in the same frame; true airspeed; commanded and realised Mach; ground track; aircraft heading where retained; bank; vertical speed; temperature, pressure and weather coverage |
| Fuel and mass | Remaining engine fuel and APU reserve distinguished; total mass; instantaneous fuel flow with units; mass/fuel origin and event timing |
| Forces and support | Lift, drag and thrust with magnitude, direction/frame and units; relevant aerodynamic coefficients; support margins, limit flags, first stopping condition and integration phase |
| Satellite evidence | Permitted-epoch predicted quantities and residuals; units and sign conventions; fitted, diagnostic, held-out or acceptance role; terminal-treatment flags; applicable tolerances and model convention |
| Rendering and completeness | Sampling cadence, gaps, saved versus derived/interpolated origin, and explicit evidence that all required samples/responses are present |

Protected epochs and their observation, prediction and residual values must be absent under the existing seal policy. The safe exporter should test that protection with synthetic sentinels before reading production records. No protected value belongs in client code, download bundles, logs or hidden UI fields.

This is an export contract for the viewer. It does not authorize a scientific run, change the catalogue, alter a Mach floor, or establish any new compatibility claim.
