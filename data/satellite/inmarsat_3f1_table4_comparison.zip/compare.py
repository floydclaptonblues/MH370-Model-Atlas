"""Compare one pinned GP solution to Table 4. Run in any directory."""
import csv
import hashlib
import json
from pathlib import Path

import erfa
import numpy as np
from astropy import units as u
from astropy.coordinates import CartesianDifferential, CartesianRepresentation, ITRS, TEME
from astropy.time import Time
from astropy.utils import iers
from sgp4.api import Satrec, WGS72

root = Path(__file__).resolve().parent
inputs = root / 'inputs'
iers.conf.auto_download = False
iers.conf.iers_degraded_accuracy = 'error'
eop = iers.IERS_B.open()
iers.earth_orientation_table.set(eop)
raw = next(inputs.glob('*.tle')).read_bytes()
meta = json.loads(next(inputs.glob('*.provenance.json')).read_bytes())
states = (inputs / 'satstate.json').read_bytes()
assert hashlib.sha256(states).hexdigest() == '0ba0f9ebe2e6258722f98c7726cd11cd732e5f38d559e940f810f560d2209a2d'
assert len(raw) == meta['raw_bytes'] == 504
assert hashlib.sha256(raw).hexdigest() == meta['raw_sha256'] == '0223860d5a37631b25234350e0d603d55912a36811b816312a5b8ee771210826'
lines = raw.decode('ascii').splitlines()
assert len(lines) == 9
sats = []
for i in (0, 3, 6):
    a, b = lines[i+1:i+3]
    for line in (a, b):
        assert len(line) == 69
        assert sum(int(c) if c.isdigit() else int(c == '-') for c in line[:68]) % 10 == int(line[68])
    assert a[:64] == lines[1][:64] and b == lines[2]
    sats.append(Satrec.twoline2rv(a, b, WGS72))
assert [s.elnum for s in sats] == [262, 263, 264]
assert all(s.satnum == 23839 and s.method == 'd' for s in sats)
epoch = Time(sats[0].jdsatepoch, sats[0].jdsatepochF, format='jd', scale='utc', precision=6)
assert epoch.isot == '2014-03-07T23:13:15.867264'

def propagate(t):
    result = [s.sgp4(t.utc.jd1, t.utc.jd2) for s in sats]
    assert result[0] == result[1] == result[2]
    error, r, v = result[0]
    if error:
        raise RuntimeError(f'SGP4 error {error} at {t.utc.isot}')
    rv = CartesianRepresentation(r*u.km, differentials=CartesianDifferential(v*u.km/u.s))
    fixed = TEME(rv, obstime=t).transform_to(ITRS(obstime=t)).cartesian
    return fixed.xyz.to_value(u.km), fixed.differentials['s'].d_xyz.to_value(u.km/u.s)

def angles(r):
    x, y, z = r
    return np.degrees([np.arctan2(z, np.hypot(x, y)), np.arctan2(y, x)])

rows = []
for src in json.loads(states):
    t = Time(src['t'] + ':00', format='iso', scale='utc')
    r, v = propagate(t)
    ref = np.array([src[k] for k in ('x','y','z')])
    vel = np.array([src[k] for k in ('vx','vy','vz')])
    dr, dv = r-ref, (v-vel)*1000
    row = dict(utc=t.isot, hours_from_epoch=(t-epoch).to_value(u.hour),
               ut1_minus_utc_s=t.delta_ut1_utc)
    for axis, pm in zip('xy', eop.pm_xy(t)):
        row[f'pole_{axis}_arcsec'] = pm.to_value(u.arcsec)
    for name, arr in [('table_km',ref),('tle_km',r),('delta_km',dr),
                      ('table_km_s',vel),('tle_km_s',v),('delta_m_s',dv)]:
        row.update({f'{name}_{axis}': val for axis,val in zip('xyz',arr)})
    row['position_norm_km'] = np.linalg.norm(dr)
    row['velocity_norm_m_s'] = np.linalg.norm(dv)
    row['radius_difference_km'] = np.linalg.norm(r)-np.linalg.norm(ref)
    for key, a, b in zip(('lat','lon'), angles(r), angles(ref)):
        row[f'tle_geocentric_{key}_deg'] = a
        row[f'table_xyz_geocentric_{key}_deg'] = b
        row[f'atlas_{key}_deg'] = src[key]
    # Independent derivative of propagated, Earth-fixed positions, +/- 5 s.
    fd = (propagate(t+5*u.s)[0]-propagate(t-5*u.s)[0])/10
    row['velocity_fd_difference_m_s'] = np.linalg.norm(v-fd)*1000
    # Cross-check velocity via the product rule, differentiating only R(t).
    def rotation(time):
        xp, yp = eop.pm_xy(time)
        polar = erfa.pom00(xp.to_value(u.rad), yp.to_value(u.rad), 0)
        theta = erfa.gmst82(time.ut1.jd1, time.ut1.jd2)
        return erfa.c2tcio(np.eye(3), theta, polar)

    _, rt, vt = sats[0].sgp4(t.utc.jd1, t.utc.jd2)
    rot = rotation(t)
    rot_dot = (rotation(t + 0.5*u.s) - rotation(t - 0.5*u.s))
    independent_v = rot @ vt + rot_dot @ rt  # matrices separated by 1 s
    row['transform_check_m_s'] = np.linalg.norm(independent_v-v)*1000
    assert np.linalg.norm(rot @ rt-r) < 1e-8
    assert row['transform_check_m_s'] < 1e-4
    assert all(abs(src[k]-val) <= 0.0005 for k,val in zip(('lat','lon'), angles(ref)))
    rows.append(row)
assert len(rows) == 11 and all(a['utc'] < b['utc'] for a,b in zip(rows,rows[1:]))
with (root/'comparison.csv').open('w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=rows[0])
    writer.writeheader()
    writer.writerows(rows)
for key in ('position_norm_km','velocity_norm_m_s','radius_difference_km','velocity_fd_difference_m_s'):
    values = np.array([r[key] for r in rows])
    print(key, 'min, max, RMS:', values.min(), values.max(), np.sqrt(np.mean(values**2)))
for r in rows:
    print(r['utc'], *(round(r[k],4) for k in ('delta_km_x','delta_km_y','delta_km_z','position_norm_km','velocity_norm_m_s','radius_difference_km')))
print('IERS B SHA256:', hashlib.sha256(Path(iers.IERS_B_FILE).read_bytes()).hexdigest())
